"use strict";
const myBtn = document.querySelector("aside button.myBtn");
const board = document.querySelector(".container-fluid aside.board");
const colorWrapper = Array.from(
  document.querySelectorAll(".colorWrapper .row")
);
myBtn.addEventListener("click", function() {
  board.classList.toggle("active");
  colorWrapper.forEach(function(item) {
    item.classList.toggle("active");
  });
});
